#include "Cukierek.h"

Cukierek::Cukierek(string _typ){
	typ = _typ;
}
string Cukierek::getTyp(){
	return typ;
}
