#ifndef CUKEIREK
#define CUKEIREK
#include<string>

using namespace std; 
class Cukierek{
	private:
		std::string typ;
	public:
		string getTyp();
		Cukierek(string _typ);

};

#endif
